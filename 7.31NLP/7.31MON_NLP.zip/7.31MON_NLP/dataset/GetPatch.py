from torch import tensor
from torch import nn
#
#
# class
#     def __init__(self, patch_size: list, patch_stride: list):
#         super(GetPatch, self).__init__()
#         self.patch_size = patch_size
#         self.patch_stride = patch_stride
#
#
# --