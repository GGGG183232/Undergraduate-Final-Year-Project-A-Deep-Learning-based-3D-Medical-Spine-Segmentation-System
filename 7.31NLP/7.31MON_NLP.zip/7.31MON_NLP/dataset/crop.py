def crop(itk_img, itk_mask):
    return itk_img, itk_mask