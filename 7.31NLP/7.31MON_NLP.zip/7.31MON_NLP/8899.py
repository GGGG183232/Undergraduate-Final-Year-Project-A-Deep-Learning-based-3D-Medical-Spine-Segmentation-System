import os
print(os.listdir('E:/savefryomxftp/'))